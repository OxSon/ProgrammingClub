package exercises1410;

/**
 * Author: Alec Mills
 *
 * Below are some coding challenges. In each there is a description of the
 * goal, a set of example Input/Output, and a method signature.
 *
 * The main method tests each of the challenges. Good luck and don't be
 * afraid to ask for help from your neighbor or a Programming Club member!
 */

public class Exercises1410 {
    /**
     * For this problem,we'll round an int value up to the next multiple of 10
     * if its rightmost digit is 5 or more, so 15 rounds up to 20.
     * Alternately, round down to the previous multiple of 10 if its rightmost
     * digit is less than 5, so 12 rounds down to 10. Given 3 ints, a b c,
     * return the sum of their rounded values. To avoid code repetition,
     * write a separate helper "public int round10(int num) {" and call it 3
     * times. Write the helper entirely below and at the same indent level as
     * roundSum().
     * <p>
     * Example inputs and results:
     * roundSum(16, 17, 18) → 60
     * roundSum(12, 13, 14) → 30
     * roundSum(6, 4, 4) → 10
     */
    private static int roundSum(int a, int b, int c) {
        //TODO
        // your solution here
        return 0;
    }

    /**
     * We'll say that a lowercase 'g' in a string is "happy" if there is
     * another 'g' immediately to its left or right. Return true if all the
     * g's in the given string are happy.
     * Example input and result:
     * gHappy("xxggxx") → true
     * gHappy("xxgxx") → false
     * gHappy("xxggyygxx") → false
     */
    public static boolean gHappy(String str) {
        //TODO
        // your solution goes here
        return false;
    }

    public static void main(String[] args) {
        boolean roundSumFailure =
                roundSum(16, 17, 18) != 60 ||
                        roundSum(12, 13, 14) != 14 ||
                        roundSum(6, 4, 4) != 10 ||
                        roundSum(0, 0, 1) != 0 ||
                        roundSum(24, 36, 32) != 90 ||
                        roundSum(12, 10, 24) != 40;

        System.out.printf("Test roundSum(): %s!%n", !roundSumFailure ?
                "PASSED" : "FAILED");

        System.out.printf("Test gHappy(): %s!%n", testgHappy() ? "PASSED" :
                "FAILED");
    }

    public static boolean testgHappy() {
        boolean success = false;
        Tuple[] strings = {
                new Tuple("xxggxx", true),
                new Tuple("xxgxx", false),
                new Tuple("gg", true),
                new Tuple("", true)
        };

        for (Tuple el : strings) {
            success = gHappy(el.str) == el.goal;
        }

        return success;
    }

    static class Tuple {
        String str;
        boolean goal;

        Tuple(String str, boolean goal) {
            this.str = str;
            this.goal = goal;
        }
    }
}
